//https://www.codechef.com/problems/KCON
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <sstream>
#include <queue>
#include <deque>
#include <bitset>
#include <iterator>
#include <list>
#include <stack>
#include <map>
#include <set>
#include <functional>
#include <numeric>
#include <utility>
#include <limits>
#include <time.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
using namespace std;
/*******  All Required define Pre-Processors and typedef Constants *******/
#define SI(t) scanf("%d",&t)
#define SL(t) scanf("%ld",&t)
#define SLLD(t) scanf("%lld",&t)
#define SCC(t) scanf("%c",&t)
#define SS(t) scanf("%s",t)
#define SCF(t) scanf("%f",&t)
#define SCLF(t) scanf("%lf",&t)
#define PI(x) printf("%d\n", x)
#define PLL(x) printf("%lld\n", x)
#define PS(s) printf("%s\n", s)
#define MEM(a, b) memset(a, (b), sizeof(a))
#define FOR(i, j, k, in) for (int i=j ; i<k ; i+=in)
#define REP(i, j) FOR(i, 0, j, 1)
#define RFOR(i, j, k, in) for (int i=j ; i>=k ; i-=in)
#define RREP(i, j) RFOR(i, j, 0, 1)
#define FOREACH(it, l) for (auto it = l.begin(); it != l.end(); it++)
#define IN(A, B, C) assert( B <= A && A <= C)
#define MP make_pair
#define PB push_back
#define INF (int)1e9
#define EPS 1e-9
#define PIE 3.1415926535897932384626433832795
#define MOD 1000000007
#define gc getchar_unlocked
#define LL long long
#define read(type) readInt<type>()
const double pi=acos(-1.0);
typedef pair<int, int> PII;
typedef pair<LL, LL> PLL;
typedef vector<PLL> VPLL;
typedef vector<int> VI;
typedef vector<LL> VL;
typedef vector<VL> VVL;
typedef vector<string> VS;
typedef vector<PII> VPII;
typedef vector<VI> VVI;
typedef map<int,int> MPII;
typedef set<int> SETI;
typedef multiset<int> MSETI;
typedef priority_queue<int>  MAX_HEAP;
typedef priority_queue<PII>  MAX_HEAP_PAIR;
typedef priority_queue<int,vector<int>,greater<int>> MIN_HEAP;
typedef priority_queue<PII,vector<PII>,greater<PII>> MIN_HEAP_PAIR;
typedef multiset<int> MIN_AVL;
typedef multiset<int,greater<int>> MAX_AVL; 
typedef long int int32;
typedef unsigned long int uint32;
typedef long long int int64;
typedef unsigned long long int  uint64;
/****** Template of some basic operations *****/
template<typename T, typename U> inline void amin(T &x, U y) { if(y < x) x = y; }
template<typename T, typename U> inline void amax(T &x, U y) { if(x < y) x = y; }
#define br printf("\n")
#define fo(i, n) for(i=0;i<n;i++)
#define Fo(i, k, n) for(i=k;k<n?i<n:i>n;k<n?i+=1:i-=1)
#define deb(x) cout << #x << " = " << x << endl;
#define deb2(x, y) cout << #x << " = " << x << ", " << #y << " = " << y << endl
#define deba(i, a, n) fo(i, n){cout << a[i] << " ";}
#define pb push_back
#define mp make_pair
#define F first
#define S second
#define all(x) x.begin(), x.end()
#define rall(x) x.rbegin(), x.rend()
#define clr(x) memset(x, 0, sizeof(x))
#define sortall(x) sort(all(x))
#define tr(it, x) for(auto it = x.begin(); it != x.end(); it++)
#define trr(it, x) for(auto it = x.rbegin(); it != x.rend(); it+)
const int mod = 1'000'000'007;
const int N = 3e5;
#define Matrix_type int
/* 2-D Array
int m,n;
cin>>m,n;
Matrix_type **arr=new Matrix_type*[m];
for(int i=0;i<m;i++){
    arr[i]=new Matrix_type [n];
    for(int j=0;j<n;j++){
        cin>>arr[i][j];
    }
}


for(int i=0;i<m;i++)
    delete aar[i];
delete[] arr;
*/
/* 2 D Multiply
void multiply(Matrix_type &F[2][2], Matrix_type &M[2][2])
{
    Matrix_type x = F[0][0] * M[0][0] + F[0][1] * M[1][0];
    Matrix_type y = F[0][0] * M[0][1] + F[0][1] * M[1][1];
    Matrix_type z = F[1][0] * M[0][0] + F[1][1] * M[1][0];
    Matrix_type w = F[1][0] * M[0][1] + F[1][1] * M[1][1];
    F[0][0] = x;
    F[0][1] = y;
    F[1][0] = z;
    F[1][1] = w;
}*//*

Matrix_type multiply(Matrix_type F[2][2], Matrix_type M[2][2])
{
	Matrix_type a = F[0][0] * M[0][0] + F[0][1] * M[1][0] + F[0][2] * M[2][0];
	Matrix_type b = F[0][0] * M[0][1] + F[0][1] * M[1][1] + F[0][2] * M[2][1];
	Matrix_type c = F[0][0] * M[0][2] + F[0][1] * M[1][2] + F[0][2] * M[2][2];
	Matrix_type d = F[1][0] * M[0][0] + F[1][1] * M[1][0] + F[1][2] * M[2][0];
	Matrix_type e = F[1][0] * M[0][1] + F[1][1] * M[1][1] + F[1][2] * M[2][1];
	Matrix_type f = F[1][0] * M[0][2] + F[1][1] * M[1][2] + F[1][2] * M[2][2];
	Matrix_type g = F[2][0] * M[0][0] + F[2][1] * M[1][0] + F[2][2] * M[2][0];
	Matrix_type h = F[2][0] * M[0][1] + F[2][1] * M[1][1] + F[2][2] * M[2][1];
	Matrix_type i = F[2][0] * M[0][2] + F[2][1] * M[1][2] + F[2][2] * M[2][2];
	F[0][0] = a;	F[0][1] = b;	F[0][2] = c;
	F[1][0] = d;	F[1][1] = e;	F[1][2] = f;
	F[2][0] = g;	F[2][1] = h;	F[2][2] = i;
	return F;
}
*/

/*void multiply(Matrix_type a[3][3], Matrix_type b[3][3])
{
	// Creating an auxiliary matrix to store elements
	// of the multiplication matrix
	Matrix_type mul[3][3];
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			mul[i][j] = 0;
			for (int k = 0; k < 3; k++)
				mul[i][j] += a[i][k]*b[k][j];
		}
	}

	// storing the multiplication result in a[][]
	for (int i=0; i<3; i++)
		for (int j=0; j<3; j++)
			a[i][j] = mul[i][j]; // Updating our matrix
}*/
/*vector <vector<long long>> map=vector <vector<long long>> (n, vector <long long>(n)) ;
vector <vector<long long>> map=vector <vector<long long>> (n, vector <long long>(n,0)) ;// all values are set to 0
const  long long large= 3e18+5; //it is of type long long and not double
void multiply(vector <vector<long long>> &mat1,vector <vector<long long>> &mat2) //matrix multi and vector call by refernce
{
    vector <vector<long long>> res=vector <vector<long long>> (mat1[0].size(), vector <long long>(mat1[0].size(),0)) ;
    for (int i = 0; i < mat1[0].size(); i++) {
        for (int j = 0; j < mat1[0].size(); j++) {
            res[i][j] = 0;
            for (int k = 0; k < mat1[0].size(); k++)
                res[i][j] = ( ( res[i][j] )  +( ( mat1[i][k] )  * ( mat2[k][j] ) ) ) ;
        }
    }
    for (int i = 0; i < mat1[0].size(); i++) {
        for (int j = 0; j < mat1[0].size(); j++) {
            mat1[i][j]=res[i][j]% MOD;
        }
    }
}

vector <vector<long long>> matrix_expo(vector <vector<long long>> &a, long long k) { vector call by refernce and vector return
  vector <vector<long long>> temp=vector <vector<long long>> (a[0].size(), vector <long long>(a[0].size(),0)) ;
  ...
  return temp;
}
int main() { //taking graph as input
  long long n,m,k,x,y;
  cin >> n>>m>>k ;
  vector <vector<long long>> map=vector <vector<long long>> (n, vector <long long>(n,0)) ;
  for(int i=0;i<m;i++){
    cin>>x>>y;
    map[x-1][y-1]=1;
  }
  vector <vector<long long>> fmap=matrix_expo(map, k);  //accepting returned vector
  cout <<ans<< "\n";
}*/

VI v[N];
int a[N];
void solution(VI arr, unsigned int k) {
     
    cout<<"result";
}
int main() {
    ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);
    int t = 1,k,n,temp;
    //SI(t);
    while(t--) {
        SI(k);
        SI(n);
        VI arr(n);
        REP(i,n){
            SI(temp);
            arr[i]=temp;
        }
        solution(arr,k);
    }
    return 0;
}