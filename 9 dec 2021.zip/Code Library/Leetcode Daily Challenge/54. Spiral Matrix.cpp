//https://leetcode.com/problems/spiral-matrix/
class Solution {
public:
    vector<int> spiralOrder(vector<vector<int>>& matrix) {
        //vector <int> ans(matrix.size()*matrix[0].size());
        vector <int> ans;
        //ans.push_back(matrix[0][0]);
        int count=0;
        int a=matrix[0].size()-1;
        int b=0;
        int c=matrix.size()-1;
        int d=matrix[0].size()-1;
        int e=0;
        int f=matrix.size()-1;
        int g=0;
        int h=0;
        while(h<=a||b<=c||f>=g||d>=e){
            /*loop h to a*/
                for(int i=h;i<a;i++){
                    ans.push_back(matrix[g][i]);
                }
                g++;
            /*loop b to c*/                
                for(int i=b;i<c;i++){

                    ans.push_back(matrix[i][a]);
                    
                }
                    //a can be d also
                a--;
            /*loop d to e*/
                for(int i=d;i>e;i--){
                    //change d-1 with d
                    ans.push_back(matrix[c][i]);}
                c--;
            /*loop f to g*/
                for(int i=f;i>g;i--){
                    ans.push_back(matrix[i][e]);
                }
                e++;
            h=e;
            f=c;
            d=a;
            b=g;
            /*repeat all*/    
        }
        //if(a==h||g==f)
            //ans.push_back(matrix[a][g]);
         return ans;       
    }
};