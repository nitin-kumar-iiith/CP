//https://leetcode.com/problems/climbing-stairs/
class Solution {
public:
    
    int solver(int curr_pos,vector <int> &arr){
        int a=0;
        int b=0;
        if(arr[curr_pos]!=-1)
            return arr[curr_pos];
        if((curr_pos-1)>0&&arr[curr_pos-1]==-1){
            a=solver(curr_pos-1,arr);
            arr[curr_pos-1]=a;
        }
        else if((curr_pos-1)>0){
            a=arr[curr_pos-1];    
        }    
        if((curr_pos-2)>0 &&arr[curr_pos-2]==-1){
            b=solver(curr_pos-2,arr);
            arr[curr_pos-2]=b;
        }
        else if((curr_pos-2)>0){
            b=arr[curr_pos-2];
        }
        arr[curr_pos]=a+b;
        return arr[curr_pos];
    }
    int climbStairs(int n) {
        if(n==0)
            return 0;
        if(n==1)
            return 1;
        if(n==2)
            return 2;
        vector <int> arr(47,-1);
        arr[0]=0;
        arr[1]=1;
        arr[2]=2;
        return solver(n,arr);
        
    }
};
