//https://leetcode.com/problems/unique-email-addresses/submissions/
class Solution {
public:
    int numUniqueEmails(vector<string>& emails) {
        unordered_set <string> stringSet;
        string at_pos="@";
        string plus_pos="+";
        int count_ans=0;
        for(int i=0;i<emails.size();i++){
            string ans;
            string str2 ;
            string str3;
            size_t found_at = emails[i].find(at_pos);
            size_t found_plus = emails[i].find(plus_pos);
            if (found_plus <= emails[i].length()){//found
                str2 = emails[i].substr (0,found_plus);
            }
            else{
                str2 = emails[i].substr (0,found_at);
            }
            for(int j=0;j<str2.length();j++){
                if(str2[j]!='.'){
                    ans+=str2[j];
                }
            }
            str3=emails[i].substr (found_at,emails[i].length()-found_at);
            ans+=str3;
            if(stringSet.find(ans)==stringSet.end()){
                count_ans++;
                stringSet.insert(ans);
            }
        }
        return count_ans;
    }
};
