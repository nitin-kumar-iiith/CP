//https://leetcode.com/problems/maximum-length-of-a-concatenated-string-with-unique-characters/
class Solution {
public:
    int ans=0;
    int take_dont_take(vector <int> arr,int pos, int holder){
        if(pos==arr.size())
            return __builtin_popcount(holder);
        else{
            int a=take_dont_take(arr,pos+1,holder);
            int b=0;
            if(((holder^(arr[pos]))==(holder|(arr[pos]))))
            b=take_dont_take(arr,pos+1,holder|arr[pos]);
            return max(a,b);
        }
        return 0;
    }
    int maxLength(vector<string>& arr) {
        vector <int> aux;
        for(int i=0;i<arr.size();i++){
            int curr_ele=0;
            for(int j=0;j<arr[i].size();j++){
                if((curr_ele>>(arr[i][j]-'a'))&1){//string itself has duplicates elements
                    curr_ele=0;    break;
                }
                curr_ele=curr_ele|(1<<(arr[i][j]-'a'));
            }
            if(curr_ele!=0)
            aux.push_back(curr_ele);
        }
        return take_dont_take(aux,0,0);
    }
};