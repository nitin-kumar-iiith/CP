//https://leetcode.com/problems/find-winner-on-a-tic-tac-toe-game/
class Solution {
public:
    string tictactoe(vector<vector<int>>& moves) {
        int arr[3][3]={{-1,-1,-1},{-1,-1,-1},{-1,-1,-1}};
        //1 means A, 0 means B
        int p=1;
        for(int i=0;i<moves.size();i++){
            arr[moves[i][0]][moves[i][1]]=p;
            p=abs(p-1);
        }
        int count,choice;
        for(int i=0;i<3;i++){
            count=0;
            choice=arr[i][0];
            for(int j=0;j<3;j++){
                if(arr[i][j]==-1)
                    break;
                else if(choice==arr[i][j]){
                    count++;
                }
                else if(choice!=arr[i][j]){
                    break;
                }
            }
            if(count==3){
                if(choice==1)   
                    return "A";
                else if(choice==0)   
                    return "B";
            }         
        }
        for(int i=0;i<3;i++){
            count=0;
            choice=arr[0][i];
            for(int j=0;j<3;j++){
                if(arr[j][i]==-1)
                    break;
                else if(choice==arr[j][i]){
                    count++;
                }
                else if(choice!=arr[j][i]){
                    break;
                }
            }
            if(count==3){
                if(choice==1)   
                    return "A";
                else if(choice==0)   
                    return "B";
            }         
        }
        if(arr[0][0]==arr[1][1]&&arr[1][1]==arr[2][2]){
            if(arr[0][0]!=-1){
                if(arr[0][0]==1)
                    return "A";
                if(arr[0][0]==0)
                    return "B";
            }
        }
        if(arr[0][2]==arr[1][1]&&arr[1][1]==arr[2][0]){
            if(arr[1][1]!=-1){
                if(arr[1][1]==1)
                    return "A";
                if(arr[1][1]==0)
                    return "B";
            }
        }
        if(moves.size()!=9)
            return "Pending";
        return "Draw";
    }
};