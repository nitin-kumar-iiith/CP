//https://leetcode.com/problems/longest-turbulent-subarray/
class Solution {
public:
    int maxTurbulenceSize(vector<int>& arr) {
        if(arr.size()==1)
            return 1;
        vector <int> helper(arr.size());
        helper[0]=0;
        bool flag=false;
        if(arr[0]<arr[1]){//insert 1 if arr[i]<arr[i+1]
            flag=true;
        }
        int temp=arr[0];
        for(int i=1;i<arr.size();i++){
            if(arr[i-1]<arr[i]&&flag){
                helper[i]=1;
            }
            else if(arr[i-1]>arr[i]&&flag==false){
                helper[i]=1;
            }
            else if(arr[i-1]==arr[i])
                helper[i]=2;
            else
                helper[i]=0;
            
        }
        for( int i=0;i<helper.size();i++)
            cout<<helper[i];
        int curr_max=0,prev=helper[0],curr_size=0;
    for(int i=1;i<helper.size();i++){
            if(helper[i]==2){
                curr_size=0;
            }
            else if(helper[i]!=helper[i-1]){
                curr_size++;
                curr_max=max(curr_max,curr_size);
            }
            else{
                curr_size=1;
            }
                
        }
        return curr_max+1;
        
    }
};