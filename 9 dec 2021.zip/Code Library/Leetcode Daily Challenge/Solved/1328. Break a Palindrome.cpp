//https://leetcode.com/problems/break-a-palindrome/
class Solution {
public:
    string breakPalindrome(string palindrome) {
        if(palindrome.size()==1)
            return "";
        int i;
        for(i=0;i<palindrome.size();i++){
            if(palindrome[i]!='a'/*&&skip mid point*/){
                if((palindrome.size()&1)&&(i==palindrome.size()/2))
                    continue;
                palindrome[i]='a';
                break;
            }
        }
        if(i==palindrome.size()){
            palindrome[i-1]='b';
        }
        return palindrome;
    }
};