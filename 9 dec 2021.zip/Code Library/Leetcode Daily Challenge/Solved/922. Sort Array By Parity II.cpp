//https://leetcode.com/problems/sort-array-by-parity-ii/
class Solution {
public:
    vector<int> sortArrayByParityII(vector<int>& nums) {
        vector<int> ans(nums.size());
        int odd_pointer=1,even_pointer=0;
        for(int x:nums){
            if((x&1)==1){
                ans[odd_pointer]=x;
                odd_pointer++;
                odd_pointer++;
                
            }
            else{
                ans[even_pointer]=x;
                even_pointer++;
                even_pointer++;
            }
        }
        return ans;
    }
};