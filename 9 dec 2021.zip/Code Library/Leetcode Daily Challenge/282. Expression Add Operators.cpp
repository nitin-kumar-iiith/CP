//https://leetcode.com/problems/expression-add-operators/
class Solution {
public:
    vector<string> ans;
    void solver(string original_num,string helper,int pos_in_original_string, int target){
        if(pos_in_original_string==original_num.size())
        {
            int result;
            //result=calculator(helper);
            if(result==target)
                ans.push_back(helper);
            return ;
        }
        else {
            //add + in helper string then call 
            //solver(original_num,helper,pos_in_original_string+1,target)
            //remove + from string
            
            //add - in helper string then call 
            //solver(original_num,helper,pos_in_original_string+1,target)
            //remove - from string
            
            //add * in helper string then call 
            //solver(original_num,helper,pos_in_original_string+1,target)
            //remove * from string
            
            //add "one digit" in helper string from original string then call 
            //solver(original_num,helper,pos_in_original_string+1,target)
            //remove "one digit" from string
        }
    }   
    vector<string> addOperators(string original_num, int target) {
        int pos_in_string=0;
        string helper;
        solver(original_num,helper,pos_in_original_string,target);
        return ans;
    }
};
