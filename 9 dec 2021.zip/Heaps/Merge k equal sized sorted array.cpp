#include<bits/stdc++.h>
#define N 105
using namespace std;
typedef pair<int,int> PII;
typedef priority_queue<PII,vector<PII>,greater<PII>> MIN_HEAP;
typedef vector<int> VI;
#define FOR(i, j, k, in) for (int i=j ; i<k ; i+=in)
#define REP(i, j) FOR(i, 0, j, 1)
void printArray(vector<int> arr, int size)
{
for (int i=0; i < size; i++)
	cout << arr[i] << " ";
}

class Solution
{
    public:
    vector<int> mergeKArrays(vector<vector<int>> arr, int K)
    {
        MIN_HEAP minh;
        VI ans;
        vector <int> pointer(arr.size(),1);
        REP(i,K){
            minh.push(make_pair(arr[i][0],i));
        }
        while(minh.size()>0){
            pair<int, int> temp=minh.top();
            minh.pop();
            ans.push_back(temp.first);
            if(K>pointer[temp.second]){
                minh.push(make_pair(arr[temp.second][pointer[temp.second]],temp.second));
                pointer[temp.second]++;
            }
        }
        return ans;
    }
};
int main()
{
	int t;
	cin>>t;
	while(t--){
	    int k;
	    cin>>k;
	    vector<vector<int>> arr(N, vector<int> (N, 0));
	    for(int i=0; i<k; i++){
	        for(int j=0; j<k; j++)
	        {
	            cin>>arr[i][j];
	        }
	    }
	    Solution obj;
    	vector<int> output = obj.mergeKArrays(arr, k);
    	printArray(output, k*k);
    	cout<<endl;
    }
	return 0;
}