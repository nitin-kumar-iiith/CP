#include <bits/stdc++.h>
using namespace std;
class Solution
{  
    public:
    void heapSort(int arr[], int n)
    {
        vector <int> ans(n);
        priority_queue <int , vector <int> , greater <int>> minh;
        for(int i=0;i<n;i++){
            minh.push(arr[i]);
        }
        for(int i=0;i<n;i++){
            arr[i]=minh.top();
            minh.pop();
        }
    }
};
void printArray(int arr[], int size)
{
    int i;
    for (i=0; i < size; i++)
        printf("%d ", arr[i]);
    printf("\n");
}
int main()
{
    int arr[1000000],n,T,i;
    scanf("%d",&T);
    while(T--){
    scanf("%d",&n);
    for(i=0;i<n;i++)
      scanf("%d",&arr[i]);
    Solution ob;
    vector <int> ans(n);
    ob.heapSort(arr, n);
    printArray(arr, n);
    }
    return 0;
}