#include<bits/stdc++.h>
using namespace std;
typedef pair<int, int> PII;
typedef priority_queue<PII,vector<PII>,greater<PII>> MIN_HEAP;
#define FOR(i, j, k, in) for (int i=j ; i<k ; i+=in)
#define REP(i, j) FOR(i, 0, j, 1)
typedef vector<int> VI;
#define N 1000
class Solution{
    public:
    pair<int,int> findSmallestRange(int arr[][N], int n, int k)
    {
        int min_=INT_MAX;
        int max_=-INT_MAX;
        int ans_min,ans_max;
        MIN_HEAP minh;
        VI pointer(k,0);
        REP(i,k){
            int temp=arr[i][0];
            //pointer[i]++;
            minh.push(make_pair(temp,i));
            if(temp>max_){
                max_=temp;
            }
            if(temp<min_){
                min_=temp;
            }
        }//all coorrect till here
        //int range=INT_MAX-1;
        //int min_range=INT_MAX;
        /*REP(i,k){
                if((pointer[i]<=n)&&(min_>arr[i][pointer[i]])){
                    min_=arr[i][pointer[i]];
                }
        }*/
        int range=max_-min_;
        int min_range=range;
        ans_min=min_;
        ans_max=max_;
        while(true){
            pair <int,int> temp=minh.top();
            minh.pop();
            pointer[temp.second]++;
            int element=arr[temp.second][pointer[temp.second]];
            if(pointer[temp.second]<n)
                minh.push(make_pair(element,temp.second));
            if(element>max_){
                max_=element;
            }
            //find min
            min_=INT_MAX;
            //min_=temp.first;
            REP(i,k){
                if((pointer[i]<=n)&&(min_>arr[i][pointer[i]])){
                    min_=arr[i][pointer[i]];
                }
            }
            range=(max_-min_);
            if(range<min_range){
                min_range=range;
                ans_max=max_;
                ans_min=min_;
            }
            if(pointer[temp.second]>=n)
                break;
        }
        return make_pair(ans_min,ans_max);
    }
};
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n, k;
        cin>>n>>k;
        int arr[N][N];
        pair<int,int> rangee;
        for(int i=0; i<k; i++)
            for(int j=0; j<n; j++)
                cin>>arr[i][j];
        Solution obj;
	    rangee = obj.findSmallestRange(arr, n, k);
	    cout<<rangee.first<<" "<<rangee.second<<"\n";
    }   
	return 0;
}
/*
passed
IP
1
5 3
1 3 5 7 9
0 2 4 6 8
2 3 5 7 11
OP
1 2*/


/*
passed
IP
1
4 3
1 2 3 4
5 6 7 8
9 10 11 12
OP
4 9*/

/*
passed
IP
1
5 3
1 3 5 7 9
0 2 4 6 8
2 3 5 7 11
OP
1 2*/

/*
passed
IP
1
10 3
1 2 4 5 7 8 11 15 17 19
0 2 4 6 8 10 12 14 16 18
1 3 5 7 9 11 13 15 17 19
OP
0 1*/



/*failing for*/
/*IP
2 64
2833 4015
3502 4260
690 5696
622 9344
760 8771
6626 8487
6065 8580
5846 7589
3235 5340
494 9699
1699 7030
6366 9961
5666 8765
2182 5378
3941 9699
7683 8884
7538 7956
5 3144
3766 8228
3352 9349
2327 4526
1839 6944
5780 7259
2600 9142
5367 9636
7067 8651
3018 8612
3433 8136
4278 5163
318 330
4354 9105
3413 9214
1892 2359
3418 6472
2477 9119
7004 9824
1663 7798
300 5058
3796 9442
4010 9163
2661 9078
2097 2582
1274 2367
233 1904
6903 7531
2234 2988
1257 7801
6401 9501
6172 6512
5974 8989
5291 5798
2345 9442
2645 3814
3962 4500
2087 4862
7518 9477
2060 3875
1501 5967
779 2552
3406 8310
1992 9455
7065 7650
4052 9793
2918 6305*/
//OP 330 7683
