#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <sstream>
#include <queue>
#include <deque>
#include <bitset>
#include <iterator>
#include <list>
#include <stack>
#include <map>
#include <set>
#include <functional>
#include <numeric>
#include <utility>
#include <limits>
#include <time.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

using namespace std;

/*******  All Required define Pre-Processors and typedef Constants *******/
#define SI(t) scanf("%d",&t)
#define SL(t) scanf("%ld",&t)
#define SLLD(t) scanf("%lld",&t)
#define SCC(t) scanf("%c",&t)
#define SS(t) scanf("%s",t)
#define SCF(t) scanf("%f",&t)
#define SCLF(t) scanf("%lf",&t)



#define PI(x) printf("%d\n", x)
#define PLL(x) printf("%lld\n", x)
#define PS(s) printf("%s\n", s)


#define MEM(a, b) memset(a, (b), sizeof(a))
#define FOR(i, j, k, in) for (int i=j ; i<k ; i+=in)
#define RFOR(i, j, k, in) for (int i=j ; i>=k ; i-=in)
#define REP(i, j) FOR(i, 0, j, 1)
#define RREP(i, j) RFOR(i, j, 0, 1)
#define FOREACH(it, l) for (auto it = l.begin(); it != l.end(); it++)
#define IN(A, B, C) assert( B <= A && A <= C)
#define MP make_pair
#define PB push_back
#define INF (int)1e9
#define EPS 1e-9
#define PIE 3.1415926535897932384626433832795
#define MOD 1000000007
#define gc getchar_unlocked
#define LL long long
#define read(type) readInt<type>()
const double pi=acos(-1.0);
typedef pair<int, int> PII;
typedef pair<LL, LL> PLL;
typedef vector<PLL> VPLL;
typedef vector<int> VI;
typedef vector<LL> VL;
typedef vector<VL> VVL;
typedef vector<string> VS;
typedef vector<PII> VPII;
typedef vector<VI> VVI;
typedef map<int,int> MPII;
typedef set<int> SETI;
typedef multiset<int> MSETI;
typedef priority_queue<int>  MAX_HEAP;
typedef priority_queue<int,vector<int>,greater<int>> MIN_HEAP;
typedef multiset<int> MIN_AVL;
typedef multiset<int,greater<int>> MAX_AVL; 
typedef long int int32;
typedef unsigned long int uint32;
typedef long long int int64;
typedef unsigned long long int  uint64;
/****** Template of some basic operations *****/
template<typename T, typename U> inline void amin(T &x, U y) { if(y < x) x = y; }
template<typename T, typename U> inline void amax(T &x, U y) { if(x < y) x = y; }
#define br printf("\n")
#define fo(i, n) for(i=0;i<n;i++)
#define Fo(i, k, n) for(i=k;k<n?i<n:i>n;k<n?i+=1:i-=1)
#define deb(x) cout << #x << " = " << x << endl;
#define deb2(x, y) cout << #x << " = " << x << ", " << #y << " = " << y << endl
#define deba(i, a, n) fo(i, n){cout << a[i] << " ";}
#define pb push_back
#define mp make_pair
#define F first
#define S second
#define all(x) x.begin(), x.end()
#define rall(x) x.rbegin(), x.rend()
#define clr(x) memset(x, 0, sizeof(x))
#define sortall(x) sort(all(x))
#define tr(it, x) for(auto it = x.begin(); it != x.end(); it++)
#define trr(it, x) for(auto it = x.rbegin(); it != x.rend(); it+)
const int mod = 1'000'000'007;
const int N = 3e5;
VI v[N];
int a[N];
void solution(VI arr, unsigned int k) {
    MIN_HEAP minh;
    int n=arr.size();
    VI sum(n+1);
    sum[0]=0;
    sum[1]=arr[0];
    for(int i=2;i<=n;i++){
        sum[i]=sum[i-1]+arr[i-1];
    }
    for(int i=1;i<=n;i++){
        for(int j=i;j<=n;j++){
            int temp=sum[j]-sum[i-1];
            if(minh.size()<k){
                minh.push(temp);
            }
            else if(minh.top()<temp){
                minh.push(temp);
            }
            if(minh.size()>k){
                minh.pop();
            }
        }
    }
    cout<<minh.top();
}
int main() {
    ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);
    int t = 1,k,n,temp;
    //SI(t);
    while(t--) {
        SI(k);
        SI(n);
        VI arr(n);
        REP(i,n){
            SI(temp);
            arr[i]=temp;
        }
        solution(arr,k);
    }
    return 0;
}