#include <bits/stdc++.h>
using namespace std;
typedef priority_queue<int>  MAX_HEAP;
typedef priority_queue<int,vector<int>,greater<int>> MIN_HEAP;
#define FOR(i, j, k, in) for (int i=j ; i<k ; i+=in)
#define REP(i, j) FOR(i, 0, j, 1)
class Solution
{
    public:
    MAX_HEAP maxh;
    int maxh_count=0;
    MIN_HEAP minh;
    int minh_count=0;
    //Function to insert heap.
    void insertHeap(int &x)
    {   
        /*if(((minh.size()-maxh.size()))>=2||((minh.size()-maxh.size()))<=2)
            balanceHeaps();*/
        if(minh_count==0){
            minh.push(x);
            minh_count++;
        }
        else if(minh_count==0){
            maxh.push(x);
            maxh_count++;
        }
        balanceHeaps();
        if(x>=minh.top()){//before push check size and decide where to push
            minh.push(x);
            minh_count++;
        }
        else if(x<=maxh.top()){
            maxh.push(x);
            maxh_count++;
        }
        balanceHeaps();
    }
    //Function to balance heaps.
    void balanceHeaps()
    {   //beofre balancing check elements in heap exists or not
        if((abs(maxh_count-minh_count)>1)&&(maxh_count>minh_count)){
            while((abs(maxh_count-minh_count)!=1)||(abs(maxh_count-minh_count)!=0)){
                //note one of the above cont=dition will always be true
                int temp=maxh.top();
                maxh_count--;
                maxh.pop();
                minh.push(temp);
                minh_count++;
            }
        }
        else if((abs(maxh_count-minh_count)>1)&&(maxh_count<minh_count)){
            while((abs(maxh_count-minh_count)!=1)||(abs(maxh_count-minh_count)!=0)){
                //note one of the above cont=dition will always be true
                int temp=minh.top();
                minh_count--;
                minh.pop();
                maxh.push(temp);
                maxh_count++;
            }
        }        
    }
    //Function to return Median.
    double getMedian()
    {
        
    }
};
int main()
{
    int n, x;
    int t;
    cin>>t;
    while(t--)
    {
    	Solution ob;
    	cin >> n;
    	for(int i = 1;i<= n; ++i)
    	{
    		cin >> x;
    		ob.insertHeap(x);
    	    cout << floor(ob.getMedian()) << endl;
    	}
    }
	return 0;
}