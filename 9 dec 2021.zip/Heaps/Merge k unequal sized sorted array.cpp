#include<bits/stdc++.h>
using namespace std;
typedef pair<int,int> PII;
typedef vector<int> VI;
typedef vector<VI> VVI;
#define SI(t) scanf("%d",&t)
typedef priority_queue<PII,vector<PII>,greater<PII>> MIN_HEAP;
#define FOR(i, j, k, in) for (int i=j ; i<k ; i+=in)
#define REP(i, j) FOR(i, 0, j, 1)
void printArray(vector<int> arr)
{
    for (unsigned int i=0; i < arr.size(); i++)
	    cout << arr[i] << " ";
}
class Solution
{
    public:
    vector<int> mergeKArrays(VVI arr)
    {
        MIN_HEAP minh;
        VI ans;
        vector <int> pointer(arr.size(),1);
        int K=arr.size();       
        REP(i,K){
            minh.push(make_pair(arr[i][0],i));
        }
        while(minh.size()>0){
            pair<int, int> temp=minh.top();
            minh.pop();
            ans.push_back(temp.first);
            if(arr[temp.second].size()>(unsigned)pointer[temp.second]){
                minh.push(make_pair(arr[temp.second][pointer[temp.second]],temp.second));
                pointer[temp.second]++;
            }
        }
        return ans;
    }
};
int main()
{
	int t,num_col,temp;
    SI(t);

	while(t--){
	    int k;
        SI(k);
        VVI matrix(k);
        //VVI matrix;
        for(int i=0; i<k; i++){
            SI(num_col);
            VI rows(num_col);
            //VI rows;
	        for(int j=0; j<num_col; j++)
	        {
                SI(temp);
	            rows[j]=temp;
                //rows.push_back(temp);
	        }
            matrix[i]=rows;
            //matrix.push_back(rows);
	    }
	    Solution obj;
    	vector<int> output = obj.mergeKArrays(matrix);
    	printArray(output);
    	cout<<endl;
    }
	return 0;
}
/*IP
2
3 
2 1 3
3 2 4 6
4 0 9 10 11
2
3 1 3 20
3 2 4 6*/
/*OP
0 1 2 3 4 6 9 10 11 
1 2 3 4 6 20 
*/