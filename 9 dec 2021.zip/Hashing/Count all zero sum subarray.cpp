#include<bits/stdc++.h>
#include<map>
using namespace std;
#define FOR(i, j, k, in) for (int i=j ; i<k ; i+=in)
#define REP(i, j) FOR(i, 0, j, 1)
class Solution{
    public:

    long long findSubarray(vector<long long> arr, int n ) {
        long long ans=0;
        long long sum=0;
        map <long long,int> mapper;
        mapper[0]=1;
        REP(i,n){
            sum+=arr[i];
            if(mapper.find(sum)!=mapper.end()){
                ans+=mapper[sum]++;
            }
            else{
                mapper[sum]=1;
            }
        }
        return ans;
    }
};

int main()
 {
    int t;
    cin>>t;
    while(t--)
    {
        int n;
        cin>>n;
        vector<long long> arr(n,0);
        for(int i=0;i<n;i++)
            cin>>arr[i];
        Solution ob;
        cout << ob.findSubarray(arr,n) << "\n";
    }
	return 0;
}
/*IP
2
6
0 0 5 5 0 0
10
6 -1 -3 4 -2 2 4 6 -12 -7
OP
6
4*/