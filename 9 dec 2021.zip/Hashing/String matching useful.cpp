#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#define SI(t) scanf("%d",&t)
#define SS(t) scanf("%s",t)
#define FOR(i, p, k, in) for (unsigned int i=p ; i<k ; i+=in)
#define REP(i, p) FOR(i, 1, p, 1)
#define MOD 1000000007 
#define alpha 26
using namespace std;
typedef vector<int> VI;
int main() {
    int test;
    SI(test);
    while(test--){
        string str;
        cin>>str;
        VI pre(str.size(),-1);
        VI post(str.size(),-1);
        string s=str;
        long hasher = 0, mul = 1;
        unsigned int i;
        for (i = 0; i<  str.length(); i++) {
            int start = s[i] - 'a';
            long long temp1 = (hasher * alpha ) % MOD;
            hasher = (temp1 + start) % MOD;
            pre[i]=hasher;;
        }
        hasher = 0; mul = 1; 
        for (i = str.length() - 1; i > 0;  i--) {
            int end = s[i] - 'a';
            long long temp=(mul * end) % MOD;
            hasher = (hasher + temp) % MOD;
            long long temp1 = mul % MOD;
            long long temp2 = alpha % MOD;
            mul = temp1 * temp2 % MOD;
            post[i]=hasher;
        }
        int ans = 0;
        unsigned int j = str.length() - 1;
        for (i = 0; j > 0; ++i) {
            if (pre[i] == post[j])
                ans = i + 1;
            --j;
        }
        if(ans>0)
        cout<<ans<<" ";
    }
    return 0;
}
