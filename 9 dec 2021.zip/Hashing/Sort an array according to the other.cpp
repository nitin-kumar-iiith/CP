#include <bits/stdc++.h> 
using namespace std;
#define FOR(i, j, k, in) for (int i=j ; i<k ; i+=in)
#define REP(i, j) FOR(i, 0, j, 1)
typedef map<int,int> MPII;
class Solution{
    public:
    // A1[] : the input array-1
    // N : size of the array A1[]
    // A2[] : the input array-2
    // M : size of the array A2[]
    
    //Function to sort an array according to the other array.
    vector<int> sortA1ByA2(vector<int> A1, int N, vector<int> A2, int M) 
    {
        //vector<int> ans(N);
        vector<int> ans;
        vector<int> aux;
        MPII mapper;
        REP(i,N){
            /*if(mapper.find(A1[i])==mapper.end()){
                mapper.insert(A1[i],1);
            }
            else */ //this part is giving error, don't know why
                mapper[A1[i]]++;
        }
        REP(i,M){
            auto itr=mapper.find(A2[i]);
            if(itr!=mapper.end()){
                int j=0;
                while(j<itr->second){
                    ans.push_back(itr->first);
                    j++;
                }
                mapper.erase(A2[i]);
            }
        }
        /*for (auto i : mapper){
            int temp=i.second;
            while(temp--){
                ans.push_back(i.first);
            }
        }*/  //you can replace next 7 lines using this above block also
        REP(i,N){
            if(mapper.find(A1[i])!=mapper.end()){
                aux.push_back(A1[i]);
            }
        }
        sort(aux.begin(),aux.end());
        ans.insert(ans.end(),aux.begin(),aux.end());
        //ans.insert(std::end(ans), std::begin(aux), std::end(aux));
        return ans;
    } 
};
int main(int argc, char *argv[]) 
{ 
	int t;
	cin >> t;
	while(t--){
	    int n, m;
	    cin >> n >> m;
	    vector<int> a1(n);
	    vector<int> a2(m);
	    for(int i = 0;i<n;i++){
	        cin >> a1[i];
	    }
	    for(int i = 0;i<m;i++){
	        cin >> a2[i];
	    }
	    Solution ob;
	    a1 = ob.sortA1ByA2(a1, n, a2, m); 
	    for (int i = 0; i < n; i++) 
		    cout<<a1[i]<<" ";
	    cout << endl;
	}
	return 0; 
} 
/*IP
2
11 
4
2 1 2 5 7 1 9 3 6 8 8
2 1 8 3
11 
4
2 1 2 5 7 1 9 3 6 8 8
99 22 444 56 
OP
2 2 1 1 8 8 3 5 6 7 9
1 1 2 2 3 5 6 7 8 8 9*/